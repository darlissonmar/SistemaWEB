<?php
session_start();
include("conectaBD.php"); ?>
<?$query = "SELECT *FROM tb_questao";
  $result = mysql_query($query,$conexao) or die ("Error in query: $query. " .mysql_error());
  while($dados = mysql_fetch_array($result)){?>
<table> 
<tr>
  <td><textarea name="questao_enunciado"  id="questao_enunciado"><?echo $dados['tb_questao_enunciado']?></textarea></td>
  
  <?
  if($dados['tb_questao_dificuldade']==1)
        $dificildade="1-MUITO FÁCIL";
        else 
         if ($dados['tb_questao_dificuldade']==2)
                $dificildade="2-FÁCIL";
            else 
            if ($dados['tb_questao_dificuldade']==3)
                 $dificildade="3-NORMAL";
               else 
               if ($dados['tb_questao_dificuldade']==4)
                    $dificildade="4-DIFÍCIL";
                  else
                   if ($dados['tb_questao_dificuldade']==5)
                       $dificildade="5-MUITO DIFÍCIL";
   	 	    
   
      ?>
   <td><input name="questao_dificuldade" type="text" id="questao_dificuldade"  size="15"  value="<?echo $dificildade ?>"/></td>
   <td><textarea name="questao_op_1" type="text" id="questao_op_1"   ><?echo $dados['tb_questao_op_1'] ?></textarea></td>
   <td><textarea name="questao_op_2" type="text" id="questao_op_2"    ><?echo $dados['tb_questao_op_2'] ?></textarea></td>
   <td><textarea name="questao_op_3" type="text" id="questao_op_3"    ><?echo $dados['tb_questao_op_3'] ?></textarea></td>
   <td><textarea name="questao_op_4" type="text" id="questao_op_4"    ><?echo $dados['tb_questao_op_4'] ?></textarea></td>
   <td><textarea name="questao_op_5" type="text" id="questao_op_5"    ><?echo $dados['tb_questao_op_5'] ?></textarea></td>
   
   <td><input name="questao_op_correta" type="text" id="questao_op_correta"  size="2"  value="<?echo $dados['tb_questao_op_correta']?>"/></td>
   
  <td><input type="button" 
      onclick="location.href=
      '<?php echo "{$_SERVER['PHP_SELF']}?action=deletar&id={$dados['tb_questao_id']}"; ?>'" name="cancel-user" id="cancel-user" value="Remover" /></td>
  <td><input type="button" onclick="location.href=
     '<?php echo "{$_SERVER['PHP_SELF']}?action=editar&id={$dados['tb_questao_id']}"; ?>'"  name="cancel-user" id="cancel-user" value="Editar" /></td>
</tr>
</table>    		
        <?	
}
function deletar($id)
  {
  global $connection;
  
  
  $query = "DELETE FROM tb_questao
           WHERE tb_questao_id= '$id'";
        
  $query_2 = "DELETE FROM tb_assunto_and_tb_questao
           WHERE tb_questao_id= '$id'";
            
  
  $result = mysql_query($query) or die ("Error in query: $query. " .mysql_error());
  $result_2 = mysql_query($query_2) or die ("Error in query: $query. " .mysql_error());

      echo "<script>alert('questao deletada');</script>";
      echo "<script>location.href = 'editar_questao.php';</script>";
      
  }
  
  
  function editar($id)
  {
  global $connection;
  $submit = $_POST[submit];
  
  if(!$submit)
      {
      
      $query = "SELECT * 
                FROM tb_questao WHERE tb_questao_id='$id'";
  
      
      $result = mysql_query($query)
               or die 
               ("Error in query: $query. " .mysql_error());
  
      
          if(mysql_num_rows($result) >0)
          {
          
              $dados = mysql_fetch_object($result);
      
          
              ?>
<fieldset>
<p>Editando assunto </p>
<form action="<?php $_SERVER['PHP_SELF'] ?>" method="post">
  <input type="hidden" name="id" value="<?php echo $id; ?>" />
  <div id="titulo" >Enunciado:</div>
  <div>
    <textarea id="enunciado"  name="enunciado" ><?php echo $dados->tb_questao_enunciado; ?></textarea>
  </div>
  <div id="titulo" >Dificuldade:</div>
  <div>
    <textarea id="dificuldade"  name="dificuldade" ><?php echo $dados->tb_questao_dificuldade; ?></textarea>
  </div>
  <div id="titulo" >Resposta 1:</div>
  <div>
    <textarea id="op_1"  name="op_1" ><?php echo $dados->tb_questao_op_1; ?></textarea>
  </div>
  <div id="titulo" >Resposta 2:</div>
  <div>
    <textarea id="op_2"  name="op_2" ><?php echo $dados->tb_questao_op_2; ?></textarea>
  </div>
  <div id="titulo" >Resposta 3:</div>
  <div>
    <textarea id="op_3"  name="op_3" ><?php echo $dados->tb_questao_op_3; ?></textarea>
  </div>
  <div id="titulo" >Resposta 4:</div>
  <div>
    <textarea id="op_4"  name="op_4" ><?php echo $dados->tb_questao_op_4; ?></textarea>
  </div>
  <div id="titulo" >Resposta 5:</div>
  <div>
    <textarea id="op_5"  name="op_5" ><?php echo $dados->tb_questao_op_5; ?></textarea>
  </div>
   <div id="titulo" >Resposta correta:</div>
  <div>
    <textarea id="op_correta"  name="op_correta" ><?php echo $dados->tb_questao_op_correta; ?></textarea>
  </div>
  </br>
  <input type="submit"  name="submit" value="salvar!" />
</form>
</div>
</fieldset>
<?php
              echo "\n";
              }
      
      else
          {
              echo "<p>assunto não localizado no banco de dados!</p>";
              }
      }
  
  else
      {
      
      $tb_questao_enunciado = $_POST['enunciado'];
      $dificuldade = $_POST['dificuldade'];
      $op_1 = $_POST['op_1'];
      $op_2 = $_POST['op_2'];
      $op_3 = $_POST['op_3'];
      $op_4 = $_POST['op_4'];
      $op_5 = $_POST['op_5'];
      $op_correta = $_POST['op_correta'];
      
      
      
          $query = "UPDATE tb_questao 
                     SET tb_questao_enunciado = 
                     '$tb_questao_enunciado',tb_questao_dificuldade='$dificuldade',
                      tb_questao_op_correta= '$op_correta',	tb_questao_op_1='$op_1' ,
                      tb_questao_op_2 ='$op_2',tb_questao_op_3='$op_3', tb_questao_op_4='$op_4',tb_questao_op_5='$op_5' WHERE 
                      tb_questao_id = '$id'";
      
  
          $result = mysql_query($query) or die ("Error in query: $query. " .mysql_error());
      
      
      echo "<script>alert('Editado com sucesso!');</script>";
      echo "<script>location.href = 'editar_questao.php';</script>";
      
      }

  }

?>

<?switch($_GET['action']) 
          {    
              case 'deletar':
              deletar($_GET['id']);
              break;
              
              case 'editar':
              editar($_GET['id']);
              break;
             
          }?>
