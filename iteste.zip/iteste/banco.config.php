<?
	global $_host;
	global $_user;
	global $_senha;
	global $_banco;

	$_host  = "localhost";
	$_user  = "root";
	$_senha = "";
	$_banco = "iteste";
?>